package com.floatee.ai

import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.webkit.*
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class OverlayBrowserService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var panel: LinearLayout? = null
    private var web: WebView? = null
    private var status: TextView? = null
    private var apiKey: EditText? = null
    private var lastOcr = ""

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel == null) createPanel()
        return START_STICKY
    }

    private fun createPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(8,8,8,8); setBackgroundColor(0xFF191925.toInt())
        }
        val head=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text="Floatee AI"; textSize=17f; setTextColor(Color.WHITE); setPadding(8,4,8,4) },
            LinearLayout.LayoutParams(0,44,1f))
        head.addView(Button(this).apply { text="Tutup"; setOnClickListener { stopSelf() } })
        root.addView(head)
        val address=EditText(this).apply { setSingleLine(true); setText("https://www.google.com"); hint="Alamat atau pencarian"; textSize=13f }
        root.addView(address)
        fun button(t:String, f:()->Unit)=Button(this).apply { text=t; textSize=11f; setOnClickListener { f() } }
        val sites=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        sites.addView(button("Google"){ web?.loadUrl("https://www.google.com") }, LinearLayout.LayoutParams(0,42,1f))
        sites.addView(button("ChatGPT"){ web?.loadUrl("https://chatgpt.com") }, LinearLayout.LayoutParams(0,42,1f))
        sites.addView(button("Gemini"){ web?.loadUrl("https://gemini.google.com") }, LinearLayout.LayoutParams(0,42,1f))
        root.addView(sites)
        root.addView(button("Buka alamat"){ 
            var u=address.text.toString().trim()
            if (!u.startsWith("http://") && !u.startsWith("https://"))
                u=if (u.contains(".") && !u.contains(" ")) "https://$u" else "https://www.google.com/search?q="+android.net.Uri.encode(u)
            web?.loadUrl(u)
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken,0)
        })
        apiKey=EditText(this).apply { hint="OpenAI API key (opsional, sesi ini)"; textSize=12f; inputType=129 }
        root.addView(apiKey)
        status=TextView(this).apply { text="Siap. OCR memproses isi halaman browser Floatee."; textSize=11f; setTextColor(0xFFE5E0F0.toInt()); setPadding(6,6,6,6) }
        root.addView(status)
        web=WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled=true; settings.domStorageEnabled=true
            webViewClient=object:WebViewClient(){
                override fun onPageFinished(view:WebView,url:String){ address.setText(url); status?.text="Halaman siap. Tekan OCR & Analisis." }
            }
            webChromeClient=WebChromeClient()
        }
        root.addView(web,LinearLayout.LayoutParams(-1,0,1f))
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        actions.addView(button("←"){if(web?.canGoBack()==true)web?.goBack()},LinearLayout.LayoutParams(0,46,1f))
        actions.addView(button("OCR & Analisis"){ captureOcrAndAnalyze() },LinearLayout.LayoutParams(0,46,2f))
        actions.addView(button("→"){if(web?.canGoForward()==true)web?.goForward()},LinearLayout.LayoutParams(0,46,1f))
        root.addView(actions)
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params=WindowManager.LayoutParams((resources.displayMetrics.widthPixels*.94f).toInt(),
            (resources.displayMetrics.heightPixels*.78f).toInt(),type,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT)
            .apply { gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL; y=40 }
        panel=root; wm?.addView(root,params)
        web?.loadUrl("file:///android_asset/quiz.html")
    }

    private fun captureOcrAndAnalyze() {
        val view=web ?: return
        status?.text="Mengambil gambar halaman dan menjalankan OCR…"
        view.post {
            try {
                val w=view.width.coerceAtLeast(1); val h=view.height.coerceAtLeast(1)
                val bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
                view.draw(Canvas(bitmap))
                val image=InputImage.fromBitmap(bitmap,0)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        lastOcr=result.textBlocks.sortedBy { it.boundingBox?.top ?: 0 }
                            .joinToString("\n") { it.text }.trim()
                        bitmap.recycle()
                        if(lastOcr.isBlank()) status?.text="OCR tidak menemukan teks. Coba halaman lain."
                        else analyzeText(lastOcr)
                    }
                    .addOnFailureListener { bitmap.recycle(); status?.text="OCR gagal: ${it.localizedMessage}" }
            } catch(e:Exception){ status?.text="Gagal mengambil gambar halaman: ${e.localizedMessage}" }
        }
    }

    private fun analyzeText(text:String) {
        val key=apiKey?.text?.toString()?.trim().orEmpty()
        if(key.isEmpty()) { status?.text="OCR selesai (${text.length} karakter). Masukkan API key OpenAI untuk analisis AI."; return }
        status?.text="AI sedang menentukan jawaban…"
        worker.execute {
            val result=askModel(key,text.take(10000))
            main.post {
                if(result==null){status?.text="Analisis gagal. Periksa API key/koneksi."}
                else {
                    status?.text="OCR: ${text.take(180)}\nAI: $result"
                    val answer=result.trim().uppercase()
                    if(answer=="BENAR" || answer=="SALAH") clickQuizAnswer(answer)
                }
            }
        }
    }

    private fun clickQuizAnswer(answer:String) {
        // Only interact with explicit answer controls in this Floatee-owned WebView quiz.
        val js="""(function(){const a=${JSONObject.quote(answer)};const xs=[...document.querySelectorAll('[data-answer]')];const e=xs.find(x=>(x.getAttribute('data-answer')||'').toUpperCase()===a);if(e){e.click();return 'clicked '+a;}return 'no matching quiz answer control';})()"""
        web?.evaluateJavascript(js){ result -> status?.text="AI memilih $answer · $result" }
    }

    private fun askModel(key:String,text:String):String? {
        var c:HttpURLConnection?=null
        return try {
            c=(URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                requestMethod="POST";connectTimeout=20000;readTimeout=30000;doOutput=true
                setRequestProperty("Authorization","Bearer $key");setRequestProperty("Content-Type","application/json")
            }
            val prompt="Analisis teks hasil OCR berikut. Jika terdapat satu pernyataan benar/salah atau soal benar/salah, tentukan apakah pernyataan itu BENAR atau SALAH. Jika bukan soal benar/salah yang jelas, jawab TIDAK_JELAS. Keluarkan hanya satu token: BENAR, SALAH, atau TIDAK_JELAS. Jangan menebak.\n\n$text"
            val body=JSONObject().put("model","gpt-4o-mini").put("temperature",0)
                .put("messages",JSONArray().put(JSONObject().put("role","user").put("content",prompt))).toString()
            c.outputStream.use{it.write(body.toByteArray(Charsets.UTF_8))}
            if(c.responseCode !in 200..299) return null
            val raw=c.inputStream.bufferedReader().use{it.readText()}
            JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        }catch(_:Exception){null}finally{c?.disconnect()}
    }

    override fun onDestroy() {
        try{web?.stopLoading();web?.destroy()}catch(_:Exception){}
        panel?.let{try{wm?.removeView(it)}catch(_:Exception){}}
        worker.shutdownNow();panel=null;web=null;super.onDestroy()
    }
}
