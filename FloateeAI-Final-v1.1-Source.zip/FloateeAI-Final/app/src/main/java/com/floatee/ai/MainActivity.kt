package com.floatee.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(0xFF12121C.toInt())
        }
        fun text(s: String, size: Float) = TextView(this).apply {
            this.text=s; textSize=size; setTextColor(0xFFF5F2FF.toInt()); setPadding(0,8,0,8)
        }
        box.addView(text("Floatee AI", 28f))
        box.addView(text("Floating browser • OCR • AI answer helper", 14f))
        box.addView(text("Langkah 1 — Izinkan tampil di atas aplikasi lain.", 15f))
        box.addView(Button(this).apply {
            this.text="Buka izin floating window"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        })
        box.addView(text("Langkah 2 — Jalankan browser mengambang.", 15f))
        box.addView(Button(this).apply {
            this.text="Mulai Floatee Browser"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayBrowserService::class.java))
                } else Toast.makeText(this@MainActivity, "Aktifkan izin overlay dahulu", Toast.LENGTH_LONG).show()
            }
        })
        box.addView(text("Di browser Floatee, pilih Google, ChatGPT, Gemini, atau halaman latihan. OCR membaca halaman browser Floatee sendiri. AI membutuhkan API key OpenAI dan koneksi internet.", 13f))
        box.addView(text("Batasan: Floatee tidak menyamarkan diri atau melewati proteksi aplikasi lain. Pengambilan layar lintas aplikasi tidak disertakan.", 12f))
        setContentView(ScrollView(this).apply { addView(box) })
    }
}
